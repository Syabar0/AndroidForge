# NEXUS: Arena — Android build package

Upload the contents of this ZIP to an Android cloud build service.

Expected output: Android APK (debug/release depending on service settings).

Project: native Kotlin Android app, applicationId `com.nexusforge.arena`, minSdk 26, target/compile SDK 35.

If the service requires a Gradle wrapper JAR, enable its option to use the Gradle version declared in `gradle/wrapper/gradle-wrapper.properties`, or let the service generate/download the wrapper automatically.
