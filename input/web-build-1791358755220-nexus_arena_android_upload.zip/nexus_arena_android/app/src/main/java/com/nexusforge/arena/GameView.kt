package com.nexusforge.arena

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.*
import kotlin.random.Random

class GameView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val prefs = context.getSharedPreferences("save", Context.MODE_PRIVATE)
    private val rng = Random(System.currentTimeMillis())
    private var last = SystemClock.uptimeMillis()
    private var state = State.MENU
    private var score = 0
    private var best = prefs.getInt("best", 0)
    private var wave = 1
    private var level = 1
    private var xp = 0f
    private var xpNext = 100f
    private var spawnTimer = 0f
    private var fireTimer = 0f
    private var dashTimer = 0f
    private var levelChoice = false
    private var shake = 0f
    private var leftId = -1
    private var attackId = -1
    private var dashId = -1
    private var joyX = 0f
    private var joyY = 0f
    private var moveX = 0f
    private var moveY = 0f
    private var attack = false
    private var player = Player(0f, 0f)
    private val enemies = mutableListOf<Enemy>()
    private val bullets = mutableListOf<Bullet>()
    private val gems = mutableListOf<Gem>()
    private val particles = mutableListOf<Particle>()

    private enum class State { MENU, PLAYING, PAUSED, GAME_OVER }
    private data class Player(var x: Float, var y: Float, var hp: Float = 100f, var maxHp: Float = 100f, var damage: Float = 16f, var fireRate: Float = 0.28f, var speed: Float = 250f, var crit: Float = .08f, var shield: Float = 0f, var dash: Float = 0f, var inv: Float = 0f)
    private data class Enemy(var x: Float, var y: Float, var r: Float, var hp: Float, var speed: Float, var kind: Int, var hit: Float = 0f)
    private data class Bullet(var x: Float, var y: Float, var vx: Float, var vy: Float, var damage: Float, var life: Float)
    private data class Gem(var x: Float, var y: Float, var value: Int = 25)
    private data class Particle(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, var max: Float)

    init { isFocusable = true }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = SystemClock.uptimeMillis()
        val dt = ((now - last).coerceAtMost(50L)) / 1000f
        last = now
        if (state == State.PLAYING && !levelChoice) update(dt)
        drawWorld(canvas)
        postInvalidateOnAnimation()
    }

    private fun reset() {
        score = 0; wave = 1; level = 1; xp = 0f; xpNext = 100f; spawnTimer = 0f; fireTimer = 0f; dashTimer = 0f; levelChoice = false
        enemies.clear(); bullets.clear(); gems.clear(); particles.clear()
        player = Player(width * .5f, height * .5f)
        repeat(5) { spawnEnemy() }
        state = State.PLAYING
    }

    private fun update(dt: Float) {
        val w = width.toFloat(); val h = height.toFloat()
        val len = hypot(moveX, moveY).coerceAtLeast(1f)
        if (abs(moveX) > .05f || abs(moveY) > .05f) {
            player.x += moveX / len * player.speed * dt
            player.y += moveY / len * player.speed * dt
        }
        player.x = player.x.coerceIn(28f, w - 28f); player.y = player.y.coerceIn(55f, h - 28f)
        fireTimer -= dt; dashTimer -= dt; player.inv = max(0f, player.inv - dt)
        if (attack && fireTimer <= 0f) shoot()
        spawnTimer -= dt
        if (spawnTimer <= 0f) { spawnEnemy(); spawnTimer = max(.25f, 1.1f - wave * .035f) }

        for (i in enemies.indices.reversed()) {
            val e = enemies[i]; val dx = player.x - e.x; val dy = player.y - e.y; val d = hypot(dx, dy).coerceAtLeast(1f)
            e.x += dx / d * e.speed * dt; e.y += dy / d * e.speed * dt; e.hit = max(0f, e.hit - dt)
            if (d < playerRadius() + e.r && e.hit <= 0f && player.inv <= 0f) { damagePlayer(if (e.kind == 2) 18f else 9f); e.hit = .65f; e.x -= dx / d * 16f; e.y -= dy / d * 16f }
        }
        for (i in bullets.indices.reversed()) {
            val b = bullets[i]; b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt
            var removed = b.life <= 0f || b.x < -20 || b.y < -20 || b.x > w + 20 || b.y > h + 20
            if (!removed) for (j in enemies.indices.reversed()) {
                val e = enemies[j]
                if (hypot(b.x - e.x, b.y - e.y) < e.r + 5) {
                    e.hp -= b.damage; burst(e.x, e.y, 4); removed = true
                    if (e.hp <= 0) killEnemy(j, e)
                    break
                }
            }
            if (removed) bullets.removeAt(i)
        }
        for (i in gems.indices.reversed()) {
            val g = gems[i]; val d = hypot(player.x - g.x, player.y - g.y)
            if (d < 120f) { val dx = player.x - g.x; val dy = player.y - g.y; val l = hypot(dx, dy).coerceAtLeast(1f); g.x += dx / l * 300f * dt; g.y += dy / l * 300f * dt }
            if (d < 24f) { addXp(g.value); gems.removeAt(i) }
        }
        for (i in particles.indices.reversed()) { val p = particles[i]; p.x += p.vx * dt; p.y += p.vy * dt; p.life -= dt; if (p.life <= 0) particles.removeAt(i) }
        if (enemies.count { it.kind == 2 } == 0 && score > 0 && score % 1000 == 0) { }
        val targetWave = score / 500 + 1
        if (targetWave > wave) { wave = targetWave; if (wave % 5 == 0) spawnBoss() }
    }

    private fun playerRadius() = 16f
    private fun shoot() {
        val target = enemies.minByOrNull { hypot(it.x - player.x, it.y - player.y) } ?: return
        val dx = target.x - player.x; val dy = target.y - player.y; val d = hypot(dx, dy).coerceAtLeast(1f)
        val critical = rng.nextFloat() < player.crit
        bullets += Bullet(player.x, player.y, dx / d * 650f, dy / d * 650f, player.damage * if (critical) 2.2f else 1f, 1.6f)
        fireTimer = player.fireRate
        burst(player.x + dx / d * 14f, player.y + dy / d * 14f, 2)
    }

    private fun spawnEnemy() {
        val side = rng.nextInt(4); val x = if (side == 0) rng.nextFloat() * width else if (side == 1) width.toFloat() else if (side == 2) rng.nextFloat() * width else 0f
        val y = if (side == 0) 50f else if (side == 1) rng.nextFloat() * height else if (side == 2) height.toFloat() else 50f + rng.nextFloat() * (height - 50f)
        val roll = rng.nextFloat(); val kind = if (wave >= 3 && roll < .12f) 2 else if (roll < .3f) 1 else 0
        val base = 26f + wave * 3f
        enemies += Enemy(x, y, if (kind == 2) 27f else if (kind == 1) 15f else 12f, if (kind == 2) base * 10 else base * if (kind == 1) 1.6f else 1f, if (kind == 2) 38f else if (kind == 1) 80f else 58f, kind)
    }
    private fun spawnBoss() { val x = if (rng.nextBoolean()) 30f else width - 30f; enemies += Enemy(x, height * .5f, 34f, 850f + wave * 70f, 34f, 2) }
    private fun killEnemy(index: Int, e: Enemy) { enemies.removeAt(index); score += if (e.kind == 2) 250 else if (e.kind == 1) 35 else 20; gems += Gem(e.x, e.y, if (e.kind == 2) 150 else if (e.kind == 1) 40 else 25); burst(e.x, e.y, 12); shake = 6f }
    private fun addXp(v: Int) { xp += v; if (xp >= xpNext) { xp -= xpNext; level++; xpNext *= 1.22f; levelChoice = true; vibrate() } }
    private fun damagePlayer(v: Float) { var left = v; if (player.shield > 0) { val used = min(player.shield, left); player.shield -= used; left -= used }; player.hp -= left; shake = 9f; burst(player.x, player.y, 8); vibrate(); if (player.hp <= 0) { player.hp = 0f; best = max(best, score); prefs.edit().putInt("best", best).apply(); state = State.GAME_OVER } }
    private fun dash() { if (dashTimer > 0 || state != State.PLAYING) return; val len = hypot(moveX, moveY); if (len < .1f) return; player.x = (player.x + moveX / len * 130f).coerceIn(28f, width - 28f); player.y = (player.y + moveY / len * 130f).coerceIn(55f, height - 28f); dashTimer = 2f; player.inv = 0.45f; burst(player.x, player.y, 14) }
    private var inv = 0f

    private fun burst(x0: Float, y0: Float, count: Int) { repeat(count) { val a = rng.nextFloat() * PI.toFloat() * 2f; val s = rng.nextFloat() * 100f + 30f; particles += Particle(x0, y0, cos(a) * s, sin(a) * s, .35f, .35f) } }
    private fun vibrate() { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }

    private fun drawWorld(c: Canvas) {
        c.drawColor(Color.rgb(7, 10, 15)); val w = width.toFloat(); val h = height.toFloat()
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 1f; paint.color = Color.argb(24, 255, 255, 255)
        var gx = 0f; while (gx < w) { c.drawLine(gx, 48f, gx, h, paint); gx += 48f }; var gy = 48f; while (gy < h) { c.drawLine(0f, gy, w, gy, paint); gy += 48f }
        if (state == State.MENU) { drawMenu(c); return }
        drawTop(c); for (g in gems) { paint.style = Paint.Style.FILL; paint.color = Color.rgb(114,246,194); c.drawCircle(g.x, g.y, 6f, paint) }
        for (b in bullets) { paint.color = Color.WHITE; c.drawCircle(b.x, b.y, 4f, paint) }
        for (e in enemies) { paint.color = if (e.kind == 2) Color.rgb(255,86,112) else if (e.kind == 1) Color.rgb(255,176,74) else Color.rgb(123,156,255); paint.style = Paint.Style.FILL; c.drawCircle(e.x, e.y, e.r, paint); paint.color = Color.argb(100,0,0,0); c.drawCircle(e.x - e.r*.3f, e.y-e.r*.15f, e.r*.15f, paint); c.drawCircle(e.x+e.r*.3f,e.y-e.r*.15f,e.r*.15f,paint) }
        for (p in particles) { paint.color = Color.argb((255 * (p.life / p.max)).toInt().coerceIn(0,255), 114,246,194); c.drawCircle(p.x,p.y,3f,paint) }
        drawPlayer(c); drawControls(c)
        if (state == State.PAUSED) overlay(c, "ПАУЗА", "Нажми справа, чтобы продолжить")
        if (state == State.GAME_OVER) overlay(c, "GAME OVER", "Счёт: $score   •   Рекорд: $best\nНажми, чтобы начать снова")
        if (levelChoice) drawUpgrade(c)
    }

    private fun drawPlayer(c: Canvas) { paint.style = Paint.Style.FILL; paint.color = Color.rgb(114,246,194); c.drawCircle(player.x, player.y, 16f, paint); paint.color = Color.rgb(7,10,15); c.drawCircle(player.x+5,player.y-3,3f,paint); paint.color = Color.WHITE; c.drawCircle(player.x-4,player.y-3,3f,paint) }
    private fun drawTop(c: Canvas) { paint.style=Paint.Style.FILL; paint.color=Color.argb(205,9,13,20); c.drawRect(0f,0f,width.toFloat(),48f,paint); text(c,"NEXUS  •  WAVE $wave",18f,31f,Color.WHITE,18f); text(c,"LV $level",width*.48f,31f,Color.rgb(114,246,194),16f); text(c,"$score",width-78f,31f,Color.WHITE,16f); paint.color=Color.DKGRAY;c.drawRect(width-170f,38f,width-18f,42f,paint);paint.color=Color.rgb(114,246,194);c.drawRect(width-170f,38f,width-170f+152f*(xp/xpNext),42f,paint) }
    private fun drawControls(c: Canvas) { paint.style=Paint.Style.STROKE;paint.strokeWidth=2f;paint.color=Color.argb(80,255,255,255);c.drawCircle(88f,height-88f,62f,paint);c.drawCircle(88f+moveX.coerceIn(-1f,1f)*35f,height-88f+moveY.coerceIn(-1f,1f)*35f,25f,paint);button(c,width-90f,height-92f,55f,"ATTACK",Color.rgb(114,246,194));button(c,width-205f,height-60f,40f,"DASH",Color.rgb(123,156,255)) }
    private fun button(c:Canvas,x:Float,y:Float,r:Float,label:String,color:Int){paint.style=Paint.Style.FILL;paint.color=Color.argb(45,255,255,255);c.drawCircle(x,y,r,paint);paint.style=Paint.Style.STROKE;paint.color=color;c.drawCircle(x,y,r,paint);textCenter(c,label,x,y+4,color,11f)}
    private fun drawMenu(c:Canvas){textCenter(c,"NEXUS: ARENA",width/2f,height*.32f,Color.rgb(114,246,194),34f);textCenter(c,"SURVIVE • UPGRADE • DESTROY",width/2f,height*.40f,Color.LTGRAY,15f);button(c,width/2f,height*.58f,62f,"PLAY",Color.rgb(114,246,194));textCenter(c,"Рекорд: $best",width/2f,height*.76f,Color.LTGRAY,15f)}
    private fun overlay(c:Canvas,title:String,sub:String){paint.style=Paint.Style.FILL;paint.color=Color.argb(220,5,8,12);c.drawRect(0f,48f,width.toFloat(),height.toFloat(),paint);textCenter(c,title,width/2f,height*.39f,Color.rgb(114,246,194),30f);sub.split("\n").forEachIndexed{idx,s->textCenter(c,s,width/2f,height*.48f+idx*26f,Color.LTGRAY,15f)}}
    private fun drawUpgrade(c:Canvas){paint.style=Paint.Style.FILL;paint.color=Color.argb(235,7,10,15);c.drawRect(25f,65f,width-25f,height-25f,paint);textCenter(c,"LEVEL $level",width/2f,105f,Color.rgb(114,246,194),26f);textCenter(c,"Выбери улучшение",width/2f,132f,Color.LTGRAY,14f);val opts=listOf("OVERDRIVE" to "Урон +35%","RAPID FIRE" to "Скорострельность +22%","FORTRESS" to "Щит +40")
        opts.forEachIndexed{ i,(a,b)->val y=175f+i*72f;paint.style=Paint.Style.STROKE;paint.strokeWidth=2f;paint.color=Color.argb(90,114,246,194);c.drawRoundRect(55f,y,width-55f,y+55f,14f,14f,paint);text(c,"${i+1}. $a",75f,y+23f,Color.WHITE,16f);text(c,b,75f,y+44f,Color.LTGRAY,12f)}}
    private fun text(c:Canvas,s:String,x:Float,y:Float,color:Int,size:Float){paint.style=Paint.Style.FILL;paint.color=color;paint.textSize=size;paint.typeface=Typeface.create("sans",Typeface.BOLD);c.drawText(s,x,y,paint)}
    private fun textCenter(c:Canvas,s:String,x:Float,y:Float,color:Int,size:Float){paint.textSize=size;paint.typeface=Typeface.create("sans",Typeface.BOLD);paint.style=Paint.Style.FILL;paint.color=color;c.drawText(s,x-paint.measureText(s)/2f,y,paint)}

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x=e.x;val y=e.y
        when(e.actionMasked){
            MotionEvent.ACTION_DOWN,MotionEvent.ACTION_POINTER_DOWN->{val idx=e.actionIndex;val id=e.getPointerId(idx);val px=e.getX(idx);val py=e.getY(idx);if(state==State.MENU||state==State.GAME_OVER){reset();return true};if(levelChoice){val opt=((py-175f)/72f).toInt();if(opt in 0..2){when(opt){0->player.damage*=1.35f;1->player.fireRate*=.78f;2->player.shield+=40f};levelChoice=false};return true};if(state==State.PAUSED){state=State.PLAYING;return true};if(px<width*.45f&&py>height*.55f){leftId=id;joyX=px;joyY=py;moveX=0f;moveY=0f}else if(px>width*.78f&&py>height*.62f){attackId=id;attack=true}else if(px>width*.58f&&px<width*.82f&&py>height*.78f){dashId=id;dash()}else if(px>width*.88f&&py<65f){state=State.PAUSED}}
            MotionEvent.ACTION_MOVE->{if(leftId>=0){val idx=e.findPointerIndex(leftId);if(idx>=0){moveX=((e.getX(idx)-joyX)/60f).coerceIn(-1f,1f);moveY=((e.getY(idx)-joyY)/60f).coerceIn(-1f,1f)}}}
            MotionEvent.ACTION_UP,MotionEvent.ACTION_POINTER_UP,MotionEvent.ACTION_CANCEL->{val id=e.getPointerId(e.actionIndex);if(id==leftId){leftId=-1;moveX=0f;moveY=0f};if(id==attackId){attackId=-1;attack=false};if(id==dashId)dashId=-1}
        }
        return true
    }
}
