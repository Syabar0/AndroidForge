# Nexus Arena currently uses no custom ProGuard rules.
